param(
 [string]$SdkRoot='C:\Apps\CFB 27\MMC\MMC_ModManager_v1.1.0.6',
 [string]$ConfigPath="$env:LOCALAPPDATA\MMC\manager_config.json"
)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
foreach($dll in @('FrostyHash.dll','FrostySdk.dll','FrostyCore.dll')) {
 [Reflection.Assembly]::LoadFrom((Join-Path $SdkRoot $dll))|Out-Null
}
$profile=[FrostySdk.Profile]::new()
$profile.Name='CollegeFB27';$profile.DataVersion=[int][FrostySdk.ProfileVersion]::CollegeFootball27
[FrostySdk.ProfilesLibrary].GetField('m_effectiveProfile',[Reflection.BindingFlags]'NonPublic,Static').SetValue($null,$profile)
$config=Get-Content -LiteralPath $ConfigPath -Raw|ConvertFrom-Json
$game=$config.Games.CollegeFB27;$pack=$game.Options.SelectedPack
if(!$pack){throw 'No selected CollegeFB27 pack'}
$mapping=Get-Content -LiteralPath (Join-Path $root 'Evidence/collector-map.json') -Raw|ConvertFrom-Json
$targets=@{}
# Native asset hashes, not executable hashes.
foreach($collector in $mapping.PSObject.Properties) {
 foreach($asset in $collector.Value.entries.PSObject.Properties) {
  $hash=[uint32]5381
  foreach($b in [Text.Encoding]::UTF8.GetBytes($asset.Name)) {
   $hash=[uint32]((([uint64]$hash*33)-bxor $b)-band 0xffffffffL)
  }
  $targets[$hash]=$asset.Name
 }
}
$states=@{};$collectorNames=@{}
foreach($collector in $mapping.PSObject.Properties) {
 $guid=$collector.Value.guid.ToLowerInvariant();$states[$guid]=@{};$collectorNames[$guid]=$collector.Name
 foreach($asset in $collector.Value.entries.PSObject.Properties) {
  $states[$guid][$asset.Name]=@{source='Base game';entry=$asset.Value}
 }
}
$inputFolder=Join-Path $root 'Inputs/Resolved'
[IO.Directory]::CreateDirectory($inputFolder)|Out-Null
# Prior artwork profile identities, verified against current stock collectors.
# Interpret only named TeamBuilder UI rows from these collectors.
$aliases=@{
 'fab5692e-07e9-af58-43ec-0213caa708c9'='aa482f78-aa24-dbac-4547-5cd46672e895'
 '55ec74fa-5707-785a-3c0a-ab82907c4dfd'='5bf0f76a-950c-be51-e814-750e78e321a9'
}
$chunks=@{};$mods=@();$merges=@();$excluded=@();$order=0;$allLegacyCollectorsScanned=0
foreach($item in $game.Packs.$pack.Split('|')) {
 if(!$item.EndsWith(':True',[StringComparison]::OrdinalIgnoreCase)){continue}
 $file=$item.Substring(0,$item.Length-5)
 # Exclude our own prior generated overlay, even if the user renamed its file.
 $path=Join-Path (Join-Path $SdkRoot 'Mods/CollegeFB27') $file
 if(!(Test-Path -LiteralPath $path)){throw "Enabled mod missing: $path"}
 $reader=[Frosty.Core.IO.FrostyModReader]::new([IO.File]::OpenRead($path))
 try {
  if(!$reader.IsValid){throw "MMC cannot read $file"}
  $details=$reader.ReadModDetails()
  if(($file -eq 'OfflineTeamBuilder.fbmod' -and $details.Title -eq 'Offline TeamBuilder' -and $details.Author -eq 'JDHalfRack / Ace / Timberline Tex') -or ($details.Title -eq 'Offline TeamBuilder Shared UI (Automatic)' -and $details.Author -eq 'JDHalfRack / Ace / Timberline Tex')) {
   $excluded+=@($file);continue
  }
  $resources=@($reader.ReadResources());$mods+=@(@{file=$file;title=$details.Title;order=$order;resources=$resources.Count})
  foreach($r in $resources) {
   if($r.ResourceIndex -lt 0){continue}
   $guid=$r.Name.ToLowerInvariant()
   if($r.Type.ToString() -eq 'Ebx' -and $collectorNames.Values -contains $r.Name){throw "Full collector EBX override needs inspection: $file / $($r.Name)"}
   if($r.Type.ToString() -ne 'Chunk'){continue}
   if(!$r.HasHandler) {
    if($states.ContainsKey($guid) -or $aliases.ContainsKey($guid)){throw "Full collector replacement needs inspection: $file / $guid"}
    $chunks[$guid]=@{file=$file;path=$path;resourceIndex=$r.ResourceIndex;sha1=$r.Sha1.ToString();order=$order;userData=$r.UserData}
    continue
   }
   if($r.Handler -ne -1113851035){
    if($states.ContainsKey($guid) -or $aliases.ContainsKey($guid)){throw "Unsupported collector handler: $file / $guid"}
    continue
   }
   if($aliases.ContainsKey($guid)){$guid=$aliases[$guid]}
   $data=$reader.GetResourceData($r)
   $allLegacyCollectorsScanned++
   if($data.Length%52 -ne 0){throw "Invalid legacy merge length: $file / $guid"}
   if(!$states.ContainsKey($guid)){
    for($p=0;$p -lt $data.Length;$p+=52){
     if($targets.ContainsKey([BitConverter]::ToUInt32($data,$p))){throw "Unmapped collector references a target UI asset: $file / $guid. Refresh the collector profile; no output published."}
    }
    continue
   }
   $mergeFile=('merge-{0}-{1}.bin' -f $order,$r.ResourceIndex)
   [IO.File]::WriteAllBytes((Join-Path $inputFolder $mergeFile),$data)
   $merges+=@(@{file=$file;collector=$guid;payload=$mergeFile})
   for($p=0;$p -lt $data.Length;$p+=52) {
    $hash=[BitConverter]::ToUInt32($data,$p)
    if(!$targets.ContainsKey($hash)){continue}
    $asset=$targets[$hash]
    if(!$states[$guid].ContainsKey($asset)){throw 'Unexpected target hash in collector'}
    $gbytes=[byte[]]::new(16);[Array]::Copy($data,$p+4,$gbytes,0,16)
    $entry=@{guid=([Guid]::new($gbytes)).ToString();compressedOffset=[BitConverter]::ToInt64($data,$p+20);offset=[BitConverter]::ToInt64($data,$p+28);compressedSize=[BitConverter]::ToInt64($data,$p+36);size=[BitConverter]::ToInt64($data,$p+44)}
    $states[$guid][$asset]=@{source=$file;entry=$entry}
   }
  }
 }finally{$reader.Dispose()}
 $order++
}
$winners=@()
foreach($guid in $states.Keys) {
 foreach($asset in $states[$guid].Keys) {
  $state=$states[$guid][$asset];$entry=$state.entry;$chunk=$chunks[$entry.guid]
  if($chunk) {
   $reader=[Frosty.Core.IO.FrostyModReader]::new([IO.File]::OpenRead($chunk.path))
   try {
    $reader.ReadModDetails()|Out-Null
    $matches=@($reader.ReadResources()|Where-Object { $_.ResourceIndex -eq $chunk.resourceIndex -and !$_.HasHandler -and $_.Name -eq $entry.guid })
    if($matches.Count -ne 1){throw 'Winning resource is ambiguous'}
    $payload=$reader.GetResourceData($matches[0]);$payloadFile=$entry.guid+'.payload.bin'
    $sha=[Security.Cryptography.SHA1]::Create()
    try {$actual=[BitConverter]::ToString($sha.ComputeHash($payload)).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
    if($actual -ne $chunk.sha1.ToLowerInvariant()){throw "Decoded payload integrity mismatch: $($chunk.file)"}
    [IO.File]::WriteAllBytes((Join-Path $inputFolder $payloadFile),$payload)
   }finally{$reader.Dispose()}
   $winners+=@(@{asset=$asset;collector=$guid;mappingSource=$state.source;entry=$entry;payload=$payloadFile;resourceSource=$chunk.file;resourceIndex=$chunk.resourceIndex;payloadSha1=$actual})
  }else {
   $native=$mapping.PSObject.Properties|Where-Object {$_.Value.guid -eq $guid}
   $original=$native.Value.entries.$asset
   if($entry.guid -ne $original.guid -or $entry.offset -ne $original.offset -or $entry.size -ne $original.size -or $entry.compressedOffset -ne $original.compressedOffset -or $entry.compressedSize -ne $original.compressedSize){throw "Collector selects a missing resource: $asset / $($entry.guid)"}
   $winners+=@(@{asset=$asset;collector=$guid;mappingSource=$state.source;entry=$entry;resourceSource='Base game';stock=$true})
  }
 }
}
$sha256=[Security.Cryptography.SHA256]::Create()
try {$configHash=[BitConverter]::ToString($sha256.ComputeHash([IO.File]::ReadAllBytes($ConfigPath))).Replace('-','').ToLowerInvariant()}finally{$sha256.Dispose()}
@{pack=$pack;mods=$mods;excluded=$excluded;winners=$winners;merges=$merges;allLegacyCollectorsScanned=$allLegacyCollectorsScanned;unmappedTargetCollectors=0;configSha256=$configHash;configPath=$ConfigPath;gamePath=$game.GamePath;sdkRoot=$SdkRoot;order='enabled config sequence; later overrides earlier';resolvedAt=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $root 'Evidence/resolved-pack.json') -Encoding UTF8
Write-Host "Resolved $($winners.Count) UI mappings across $($mods.Count) enabled mods. No installed files changed."


