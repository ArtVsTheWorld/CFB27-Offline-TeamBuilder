"""Build the test companion from MMC's enabled pack without editing source mods."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "Tools"), str(ROOT / "Tools/vendor")]
from append_control import append_action
from bgfa_compat import read_archive
import extract_assets
import header_recipe
from inspect_tb_ast import load
from package_support import I, L, STR, U, cas, chunk, fnv32, fnv64

TITLE = "Offline TeamBuilder Shared UI (Automatic)"
AUTHOR = "JDHalfRack / Ace / Timberline Tex"
FILE = "TeamBuilderSharedUi.fbmod"
HUB = "common/ui/node_cfm/hub/corenode.ast"
CAREER = "common/ui/node_cfm/newcareer/corenode.ast"
SETUP = "common/ui/madden/ultimatecareer/screen/newcareer/customizehub.ast"
NORMAL = "ContentShared/global/RtamStorages/Presentation_Common"
GUARDS = {
    CAREER: ("Init", 0x6598, 0x65C4, {0x65AD: (0x73, 0x76)}),
    SETUP: ("_SetupHubButtons", 0x1240, 0x12A0, {0x1268: (0x58, 0), 0x1278: (0x0B, 0)}),
}


def read_json(path):
    return path.read_text(encoding="utf-8-sig")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def replace_movie(original, movie, program):
    archive = read_archive(original)
    matches = [index for index, entry in enumerate(archive.entries) if entry["raw"] == movie.data]
    if len(matches) != 1:
        raise ValueError("Expected one APT program in the selected archive")
    updated = archive.replace(matches[0], program)
    entries = read_archive(updated).entries
    if len(entries) != len(archive.entries) or entries[matches[0]]["raw"] != program:
        raise ValueError("Repacked APT program could not be verified")
    for index, (old, new) in enumerate(zip(archive.entries, entries)):
        if index != matches[0] and old["raw"] != new["raw"]:
            raise ValueError("An unrelated stream changed during APT repacking")
    return updated


def augment_hub(original, movie):
    if b"_TbHeaderVersion" in movie.data:
        if b"_TbV16OriginalRefreshHubData" in movie.data and b"_TbV16OriginalShutdown" in movie.data:
            return original, "already has the TeamBuilder v16 installer"
        raise ValueError("A different TeamBuilder header installer already owns the hub")
    initializers = []
    for _, at in movie.root_streams():
        rows = movie.decode(at)
        if any(row[1] == 0xA3 and isinstance(row[2], tuple)
               and row[2][-1] == "logic_cfm.model.mainhub.PanelMenu" for row in rows):
            initializers.append(rows)
    if len(initializers) != 1:
        raise ValueError("Could not find a unique hub PanelMenu initializer")
    rows = initializers[0]
    for name in ("_RefreshHubData", "Shutdown"):
        definitions = [row for index, row in enumerate(rows) if index and row[1] == 0x8E
                       and rows[index - 1][1] in (0xA2, 0xA3) and rows[index - 1][2][-1] == name]
        if len(definitions) != 1 or definitions[0][2][1] != 1:
            raise ValueError("Unsupported hub method signature: " + name)
    arena = header_recipe.HeaderArena(movie.data)
    arena.pad()
    start = arena.pos
    header_recipe.installer(arena, header_recipe)
    program, layout = append_action(movie, arena.finish(), start)
    preserved = bytearray(program[:len(movie.data)])
    for at, size in ((layout["frame"], 4), (layout["arrayPointer"], 8)):
        preserved[at:at + size] = movie.data[at:at + size]
    if preserved != movie.data:
        raise ValueError("Hub augmentation changed an existing action")
    return replace_movie(original, movie, program), "appended TeamBuilder v16 header refresh"


def augment_career(asset, original, movie):
    method, start, end, changes = GUARDS[asset]
    vanilla = load(ROOT / "Inputs/Stock" / NORMAL / asset)
    signature = vanilla.data[start:end]
    modified = bytearray(signature)
    for offset, (before, after) in changes.items():
        if signature[offset - start] != before:
            raise ValueError("Stock guard bytes do not match the supported recipe")
        modified[offset - start] = after
    matches = []
    for _, stream in movie.root_streams():
        rows = movie.decode(stream)
        for index, row in enumerate(rows):
            if not index or row[1] != 0x8E:
                continue
            previous = rows[index - 1]
            if previous[1] not in (0xA2, 0xA3) or previous[2][-1] != method:
                continue
            body = int(row[2][3], 16)
            limit = body + row[2][4]
            for sequence, already in ((signature, False), (bytes(modified), True)):
                cursor = movie.data.find(sequence, body, limit)
                while cursor >= 0:
                    matches.append((cursor, already))
                    cursor = movie.data.find(sequence, cursor + 1, limit)
    if len(matches) != 1:
        raise ValueError(f"{asset}: expected one TeamBuilder guard in {method}, found {len(matches)}")
    at, already = matches[0]
    if already:
        return original, f"{method} already has the TeamBuilder guard"
    program = bytearray(movie.data)
    program[at:at + len(signature)] = modified
    if sum(x != y for x, y in zip(program, movie.data)) != len(changes):
        raise ValueError("Career augmentation changed bytes outside the supported guard")
    return replace_movie(original, movie, bytes(program)), f"applied the TeamBuilder guard in {method}"


def load_input(row, collector):
    if row.get("stock"):
        return (ROOT / "Inputs/Stock" / collector / row["asset"]).read_bytes()
    payload = (ROOT / "Inputs/Resolved" / row["payload"]).read_bytes()
    if hashlib.sha1(payload).hexdigest() != row["payloadSha1"]:
        raise ValueError("The resolved archive payload changed")
    entry = row["entry"]
    start, packed = entry["compressedOffset"], entry["compressedSize"]
    offset, length = entry["offset"], entry["size"]
    if min(start, packed, offset, length) < 0 or start + packed > len(payload):
        raise ValueError("Unexpected collector bounds")
    data = extract_assets.decompress(payload[start:start + packed])[offset:offset + length]
    if len(data) != length or not data.startswith(b"BGFA"):
        raise ValueError("The resolved asset is not a complete APT archive")
    return data


def serialize(profile, version, records, payloads):
    placeholders = [b"\0" + I(-1) + STR(name) + I(0)
                    for name in ("Icon", "Screenshot0", "Screenshot1", "Screenshot2", "Screenshot3")]
    target = b"CollegeFB27"
    header = struct.pack("<QIqiB", 72155812747760198, 9, 0, len(payloads), len(target))
    header += target + U(profile["head"]) + bytes.fromhex(profile["contentHash"])
    header += b"".join(map(STR, (TITLE, AUTHOR, "Dynasty", version,
                                "Offline TeamBuilder launch-time shared UI test companion.", "")))
    resources = I(len(placeholders) + len(records)) + b"".join(placeholders + records)
    header = bytearray(header)
    struct.pack_into("<q", header, 12, len(header) + len(resources))
    offset = 0
    table = []
    for payload in payloads:
        table.append(L(offset) + L(len(payload)))
        offset += len(payload)
    return bytes(header) + resources + b"".join(table) + b"".join(payloads)


def publish(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_suffix(path.suffix + ".tmp")
    pending.write_bytes(data)
    pending.replace(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sdk", type=Path)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--seed", type=Path)
    args = parser.parse_args()
    profile = json.loads(read_json(ROOT / "Evidence/game-resource-profile.json"))
    if args.seed:
        publish(args.seed, serialize(profile, "0.1.0 seed", [], []))
        return
    if not args.sdk or not args.config:
        parser.error("--sdk and --config are required for launch preparation")
    with (args.sdk / "Caches/collegefootball27.cache").open("rb") as cache:
        header = cache.read(40)
    if len(header) != 40 or int.from_bytes(header[16:20], "little") != profile["head"] or header[20:40].hex() != profile["contentHash"]:
        raise ValueError("MMC game data does not match the November 19 test profile")
    config_sha = digest(args.config.read_bytes())
    powershell = Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"
    subprocess.run([str(powershell), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File",
                    str(ROOT / "Tools/resolve-pack.ps1"), "-SdkRoot", str(args.sdk), "-ConfigPath", str(args.config)],
                   check=True, cwd=ROOT)
    resolved = json.loads(read_json(ROOT / "Evidence/resolved-pack.json"))
    if resolved["configSha256"] != config_sha or config_sha != digest(args.config.read_bytes()):
        raise ValueError("MMC pack snapshot changed during resolution")
    if resolved.get("gamePath"):
        game = Path(resolved["gamePath"])
        extract_assets.GAME = game.parent if game.suffix.lower() == ".exe" else game
    mapping = json.loads(read_json(ROOT / "Evidence/collector-map.json"))
    names = {entry["guid"]: name for name, entry in mapping.items()}
    bundles = json.loads(read_json(ROOT / "Evidence/bundle-membership.json"))
    records, payloads, reports = [], [], []
    collector_rows = {name: [] for name in mapping}
    for asset in (HUB, CAREER, SETUP):
        rows = [row for row in resolved["winners"] if row["asset"] == asset]
        expected = {name for name, entry in mapping.items() if asset in entry["entries"]}
        if len(rows) != len(expected) or {names[row["collector"]] for row in rows} != expected:
            raise ValueError("Not all collector mappings were resolved: " + asset)
        originals = [load_input(row, names[row["collector"]]) for row in rows]
        if any(original != originals[0] for original in originals):
            raise ValueError("Normal and preload collectors select different versions of " + asset)
        original = originals[0]
        snapshot = ROOT / "Inputs/Winner" / asset
        publish(snapshot, original)
        movie = load(snapshot)
        output, result = augment_hub(original, movie) if asset == HUB else augment_career(asset, original, movie)
        packed = cas(output)
        if extract_assets.decompress(packed) != output:
            raise ValueError("Packed UI failed round-trip validation")
        key = fnv32(asset)
        guid_bytes = bytearray(uuid.uuid5(uuid.NAMESPACE_URL, "Ace/TeamBuilderSharedUi/1/" + asset).bytes_le)
        guid_bytes[15] = 1
        guid = uuid.UUID(bytes_le=bytes(guid_bytes))
        records.append(chunk(len(payloads), str(guid), packed, userdata="legacy;" + asset,
                             flags=8, logical=len(output), h32=key, h64=fnv64(asset), sbs=bundles[asset]))
        payloads.append(packed)
        for name in expected:
            collector_rows[name].append(U(key) + guid.bytes_le + struct.pack("<qqqq", 0, 0, len(packed), len(output)))
        reports.append(dict(asset=asset, result=result, source=[row["resourceSource"] for row in rows],
                            sourceSha256=digest(original), outputSha256=digest(output)))
        print(asset + " | " + result + " | " + ", ".join(sorted({row["resourceSource"] for row in rows})), flush=True)
    for name, entry in mapping.items():
        payload = b"".join(collector_rows[name])
        records.append(chunk(len(payloads), entry["guid"], payload, handler=-1113851035,
                             userdata="legacy;Collector (" + name + ")", size=len(payload)))
        payloads.append(payload)
    stable = serialize(profile, "0.1.0", records, payloads)
    version = "0.1.0 auto " + digest(stable)[:24]
    output = serialize(profile, version, records, payloads)
    publish(ROOT / "Release" / FILE, output)
    publish(ROOT / "Evidence/build-result.json", json.dumps(dict(version=version, mods=resolved["mods"],
            movies=reports, collectorRows=sum(len(rows) for rows in collector_rows.values()),
            sha256=digest(output)), indent=2).encode("utf-8"))


if __name__ == "__main__":
    main()


