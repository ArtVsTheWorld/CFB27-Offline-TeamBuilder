"""TeamBuilder v16 header installer extracted from the verified recipe."""
import struct
from apt_patch import Arena
OLD_REFRESH='_TbV16OriginalRefreshHubData'
OLD_SHUTDOWN='_TbV16OriginalShutdown'
KEY='OfflineTB/v16/HeaderReady'
class HeaderArena(Arena):
    def prototype(self):self.path('logic_cfm','model','mainhub','PanelMenu','prototype')
    def float(self,n):self.op(0xb4);self.data.extend(struct.pack('<f',n))


def stop(a):
    a.set(1,'_TbHeaderActive',False)
    a.reg(1);a.member('mIntervalMgr');a.store(3)
    a.reg(3);a.op(0x76);a.op(0x49);a.jump('done',0x9d)
    a.reg(1);a.member('_TbHeaderDelayKey');a.store(4)
    a.reg(4);a.op(0x76);a.op(0x49);a.jump('done',0x9d)
    a.method(3,'ClearDelay',(4,),True)
    a.label('done')


def arm(a):
    a.method(1,'_TbHeaderStop',(),True)
    a.reg(1);a.member('_TbHeaderDelayKey');a.op(0x76);a.op(0x49);a.jump('have_key',0xb8)
    a.prototype();a.store(8);a.reg(8);a.member('_TbHeaderNextKey');a.op(0x50);a.store(9)
    a.set(8,'_TbHeaderNextKey',(9,))
    a.reg(1);a.string('_TbHeaderDelayKey');a.string(KEY+'/');a.reg(9);a.op(0x47);a.op(0x4f)
    a.label('have_key')
    a.set(1,'_TbHeaderActive',True);a.set(1,'_TbHeaderAttempts',0)
    a.set(1,'_TbHeaderBoundLogo',-1)
    a.method(1,'_TbHeaderTick',(),True)


def refresh(a):
    a.method(1,OLD_REFRESH,(2,));a.store(10)
    a.method(1,'_TbHeaderArm',(),True);a.reg(10);a.op(0x3e)


def shutdown(a):
    a.method(1,'_TbHeaderStop',(),True)
    a.method(1,OLD_SHUTDOWN,(2,));a.op(0x3e)


def tick(a):
    a.reg(1);a.member('_TbHeaderActive');a.jump('done',0xb8)
    a.reg(1);a.member('_TbHeaderAttempts');a.num(300);a.op(0x48);a.jump('stop',0xb8)
    a.reg(1);a.member('_TbHeaderAttempts');a.op(0x50);a.store(3)
    a.set(1,'_TbHeaderAttempts',(3,))
    a.reg(1);a.member('mUcmAdapter');a.store(3)
    a.reg(3);a.op(0x76);a.op(0x49);a.jump('stop',0x9d)
    a.method(3,'IsOnlineMode');a.jump('stop',0x9d)
    a.method(3,'GetUserIsTeambuilder');a.jump('stop',0xb8)
    a.method(3,'GetUserTeamLogoId');a.store(4)
    a.reg(4);a.num(0);a.op(0x48);a.jump('retry',0x9d)
    a.path('shared_enum','fblibraries','global','TeamLogosStickers','LIBRARY_ID');a.store(5)
    a.reg(1);a.member('mParentNode');a.store(9)
    a.path('logic_com','service','FrostbiteService');a.store(8)
    a.method(8,'Get',(9,));a.store(8)
    a.reg(8);a.op(0x76);a.op(0x49);a.jump('retry',0x9d)
    # The current native binding reads argument0=library and argument1=asset.
    # This is a real availability query, not a blind fixed loading delay.
    a.method(8,'DoesImageLibraryAndAssetExist',(5,4));a.jump('unavailable',0xb8)
    a.reg(1);a.member('_TbHeaderBoundLogo');a.reg(4);a.op(0x49);a.jump('retry',0x9d)
    a.path('node_com','Global','Game');a.store(6)
    a.method(6,'GetHeader');a.store(6)
    a.reg(6);a.op(0x76);a.op(0x49);a.jump('retry',0x9d)
    a.reg(6);a.member('mcLogo');a.op(0x76);a.op(0x49);a.jump('retry',0x9d)
    a.reg(6);a.member('mLogoId');a.store(7)
    a.reg(7);a.op(0x76);a.op(0x49);a.jump('retry',0x9d)
    # Stock reset only touches the cached image, not the saved logo selection.
    # SetLogo then recomputes the current Dynasty team's actual logo ID.
    a.method(6,'UpdateLogoForTeamBuilderUpdate',(),True)
    a.method(6,'SetLogo',(7,),True)
    a.set(1,'_TbHeaderBoundLogo',(4,));a.jump('retry')
    a.label('unavailable');a.set(1,'_TbHeaderBoundLogo',-1)
    a.label('retry')
    a.reg(1);a.member('mIntervalMgr');a.store(3)
    a.reg(3);a.op(0x76);a.op(0x49);a.jump('stop',0x9d)
    a.reg(1);a.member('_TbHeaderTick');a.store(4)
    a.path('cafe','utility','Delegate');a.store(5)
    a.method(5,'Create',(1,4));a.store(5)
    a.reg(1);a.member('_TbHeaderDelayKey');a.store(4);a.float(0.1);a.store(6)
    a.method(3,'SetDelay',(4,5,6),True);a.jump('done')
    a.label('stop');a.method(1,'_TbHeaderStop',(),True)
    a.label('done')


def installer(a,m):
    a.prototype();a.member('_TbHeaderVersion');a.num(16);a.op(0x66);a.jump('installed',0x9d)
    a.alias('_RefreshHubData',m.OLD_REFRESH);a.alias('Shutdown',m.OLD_SHUTDOWN)
    for name,params,body in [('_TbHeaderStop',[],m.stop),('_TbHeaderArm',[],m.arm),('_TbHeaderTick',[],m.tick),
                             ('_RefreshHubData',['opponentLogo'],m.refresh),('Shutdown',['params'],m.shutdown)]:
        a.function(name,params,body)
    a.prototype();a.string('_TbHeaderVersion');a.num(16);a.op(0x4f)
    a.prototype();a.string('_TbHeaderNextKey');a.num(0);a.op(0x4f)
    a.label('installed');a.op(0)

